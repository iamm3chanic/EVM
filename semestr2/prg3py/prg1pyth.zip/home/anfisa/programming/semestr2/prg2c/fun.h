#ifndef __FUN_H__
#define __FUN_H__
int search(const char* fn, char* minword);
#endif