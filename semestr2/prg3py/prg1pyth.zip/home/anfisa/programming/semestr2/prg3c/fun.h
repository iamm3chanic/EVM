#ifndef __FUN_H__
#define __FUN_H__
int input1(const char *fn, int ***mat, int *str, int **strlen);
void edit(int **mat, int *str, int *strlen);
#endif
