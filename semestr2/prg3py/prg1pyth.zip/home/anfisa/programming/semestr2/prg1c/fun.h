#ifndef __FUN_H__
#define __FUN_H__
int input(const char *fn, int ***mat, int *str, int *col);
void edit(int **mat, int *str, int col);
#endif
