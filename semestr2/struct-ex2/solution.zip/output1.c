#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "fun.h"
#include "str.h"

int output1(const char *fn, List *s, int n)
{
 FILE *ff;
 int err=0;
 GoToBeg(s);
  SStudent tmp=*(s->first);
 
 /* SStudent **s;
  s=(SStudent**)malloc((n)*sizeof(**s));
 for(int i=0;i<(n);i++) (s)[i]=(SStudent*)malloc(sizeof(**s));
 for(int j=0;j<(n);j++) {s[j]=(l)->curr;  GoToNext((l));}*/
 ff=fopen(fn,"w");
 if(ff==NULL) {err=-1;goto lc;}//not found
 else
  {
   for(int i=0;i<n && !GoToNext(s);i++)
  {
   if((s)->curr->group > tmp.group) {fprintf(ff,"-------------------------\n");}
   fprintf(ff,"%d %s %f\n", (s)->curr->group, (s)->curr->name, (s)->curr->rating);   
   tmp = *(s->curr);
  }
  /*fprintf(ff,"%d %s %f\n", (s[0])->group, (s[0])->name, (s[0])->rating);
  for(int i=1;i<n;i++)
  {
   if((s[i])->group > (s[i-1])->group) {fprintf(ff, "-------------------------\n");}
   fprintf(ff,"%d %s %f\n", (s[i])->group, (s[i])->name, (s[i])->rating);
  }
  */
  err=0;
  fclose(ff);
 }
 lc:
 return err;
}
