#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "fun.h"

void edit(/*SStudent ***great, */List **l, int n, int *g)
{
 int m,flag=0; //i,j,
 SStudent *s, *s1; //SStudent ***great;
 s=(SStudent*)malloc((n)*sizeof(*s));
 //for(int i=0;i<(n);i++) (s)[i]=(SStudent*)malloc(sizeof(**s));
 GoToBeg(*l);
 for(int j=0;j<(n) && !GoToNext((*l));j++) {s[j]=*(*l)->curr; }
 s[0]=*(*l)->first;
 s[n-1]=*(*l)->last;
 
 Destruct(*l);
 (*l)=Create();
 
 m=n;
 
 for(int i=0;i<(n);i++)
  {
   for(size_t j=0;j<strlen(s[i].name);j++)
   {
   if ((s[i].name[j] >= 'A' && s[i].name[j] <='Z') ||
       (s[i].name[j] >= 'a' && s[i].name[j] <= 'z'))
       {flag=1;}
   }
   {if(flag) {m--;} /*printf("%d\n\n",m);*/ flag=0;} 
  }
 
 //if(m)
 flag=0;
 
 s1=(SStudent*)malloc((n)*sizeof(*s1));
 //*great=(SStudent**)malloc((m)*sizeof(**great));
 //for(j=0;j<(m);j++) (*great)[j]=(SStudent*)malloc(sizeof(***great));

  for(int k=0,i=0; (i<n); i++)
   {
   
   for(size_t j=0;j<strlen(s[i].name);j++)
   {
   if((s[i].name[j] >= 'A' && s[i].name[j] <='Z') ||
       (s[i].name[j] >= 'a' && s[i].name[j] <= 'z'))
       {flag=1;}
   }
   {
   if(!flag)
    {
     s1[k]=s[i];
     //*(*great)[k]=(s)[i]; 
     //memcpy((*great)[k],&(s)[i],sizeof((s)[i]));
     //printf("ss=%s\n",(s)[i].name);
     //printf("gr=%s\n",(*great)[k]->name);
     k++; 
    } 
     flag=0;
   } 
  }
  
  *g=m;
  
  
  for(int i=0;i<*g;i++)
 {
  //InsertAfter((*l),(*great)[i]->name,(*great)[i]->group,(*great)[i]->rating);
  InsertAfter((*l),(s1)[i].name,(s1)[i].group,(s1)[i].rating);
  GoToNext((*l));
 }
 
  free(s); free(s1);
}
