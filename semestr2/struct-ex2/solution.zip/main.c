#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <ctype.h>
#include <string.h>
#include "fun.h"
#include "str.h"

int main(void)
{
 int errin=0,errout=0,n=0,g;
 //SStudent **great; 
 List *arr;
 errin=input1("data.dat", &arr,&n);
 printf("checked errin=%d\n",errin);
 if(errin==-1)printf("infile not found\n");
 if(errin==-2)printf("empty file1\n");
 if(errin==-3)printf("empty file2\n");
 else if(errin==0)
 {
  errout=output1("data.res", arr,n);
  printf("checked errout=%d\n",errout);
  if (errout==-1)printf("outfile not found\n");
  else
    {sort(&arr,n);}
    printf("\nSORTED BY GROUPS:\n\n");
    output2(arr,n);
    output1("data.res", arr,n);
    edit(/*&great,*/&arr,n,&g);
    printf("\nDELETED ENGLISH:\n\n");
    output2(arr,(g));
    output1("data.res", arr,(g));
  Destruct(arr);
  //for(int i=0;i<n+1;i++) {free (s[i]);}// free (arr[i]);}
 // for(int i=0;i<g;i++) {free(great[i]);}
  //free(s); 
  //free(great); //free(arr);
 }
return errin+errout;
}
