#pragma once
typedef struct SStudent_
{
 int group;
 char name[256];
 float rating;
 struct SStudent_ *prev,*next;
}SStudent;

typedef struct List_
{
 SStudent *first,*last,*curr;
}List;
