#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "str.h"
#include "fun.h"

List *Create(void)
{List *arr;
 arr=(List *)malloc(sizeof(*arr));
 arr->first=arr->last=arr->curr=NULL;
 return arr;
}     

int GoToNext(List *arr)
{ 
 if((arr==NULL)||(arr->curr==NULL)||(arr->curr==arr->last))
  return -1;
 arr->curr=(arr->curr)->next;
 return 0;
}

void GoToBeg(List *arr)
{
 arr->curr=arr->first;
}

int IsEmpty(List *arr)
{
 return (arr==NULL)||(arr->curr==NULL);
}


void InsertAfter(List *arr, char* name, int group, float rating)
{SStudent *m;
 m=(SStudent*)malloc(sizeof(*m));
 m->next=m->prev=NULL; 
 strcpy(m->name,name);
 m->group=group;
 m->rating=rating;
 if(IsEmpty(arr))
 {arr->curr=arr->first=arr->last=m;}
 else
 {
  if(arr->curr->next==NULL)
  {
   arr->curr->next=m;
   m->prev=arr->curr;
   arr->last=m;
  }
  else
  {
   m->prev=arr->curr;
   m->next=arr->curr->next;
   arr->curr->next=m; m->next->prev=m;
  }
 } 
}

