#ifndef __FUN_H__
#define __FUN_H__
#include "str.h"
int input1(const char *fn, SStudent ***s, List ***arr, int *n);
int output1(const char *fn, SStudent **s, int n);
void output2(SStudent **s, int n);
void sort(SStudent ***s, int n);
void edit(SStudent **s,SStudent ***great, List ***arr, int n, int *g);
List *Create(void);
int GoToNext(List *a);
void GoToBeg(List *a);
void InsertAfter(List *m, char* name, int group, float rating);
int IsEmpty(List *a);
int Func(const char *SoutputFile, List **arr, int *m);
#endif
