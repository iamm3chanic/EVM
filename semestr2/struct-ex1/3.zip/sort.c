#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "fun.h"

void sort(SStudent ***s, int n)
{
 int i,j;
 SStudent t;
 for(i=0; i<n-1; i++) 
  for(j=0; j<n-1; j++)
  if ((((*s)[j])->group) > (((*s)[j+1])->group))
  {
   (t)=*(*s)[j];
   *(*s)[j]=*(*s)[j+1];
   *(*s)[j+1]=(t);
  }
}
