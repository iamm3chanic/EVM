#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "fun.h"
#include "str.h"

int output1(const char *fn, SStudent **s,int n)
{
 FILE *ff;
 int err=0;
 ff=fopen(fn,"w");
 if(ff==NULL) {err=-1;goto lc;}//not found
 else
  {
  fprintf(ff,"%d %s %f\n", (s[0])->group, (s[0])->name, (s[0])->rating);
  for(int i=1;i<n;i++)
  {
   if((s[i])->group > (s[i-1])->group) {fprintf(ff, "-------------------------\n");}
   fprintf(ff,"%d %s %f\n", (s[i])->group, (s[i])->name, (s[i])->rating);
  }
  
  err=0;
  fclose(ff);
 }
 lc:
 return err;
}
