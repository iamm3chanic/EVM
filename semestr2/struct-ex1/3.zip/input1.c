#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "fun.h"
#include "str.h"

int input1(const char *fn, SStudent ***s, List ***arr, int *n)
{
 FILE *f;
 int i,err,r,t;
 float sh;
 char str[512],u[512], *si,l;
 f=fopen(fn,"r");
 if(f==NULL){err=-1;goto lm;}//not found
 else{
 if(fgets(str,512,f)==NULL) {err=-2; goto lc;}//empty file
 else{
 if(sscanf(str,"%d",&t)!=1) {err=-3; goto lc;}//empty file2
 
 else
 {
  rewind(f);
  for(*n=0;fgets(str,512,f)!=NULL&&sscanf(str,"%d %s %f",&r,u,&sh)==3;(*n)++)
  {}//printf("n=%ld\n",*n);
  if(*n)
  *s=(SStudent**)malloc((*n)*sizeof(**s));
  for(i=0;i<(*n);i++) (*s)[i]=(SStudent*)malloc(sizeof(***s));
  rewind(f);
  for(*n=0;fgets(str,512,f)!=NULL&&sscanf(str,"%d %s %f",&((*s)[*n]->group),(*s)[*n]->name,&((*s)[*n]->rating))==3;(*n)++)
  {
//   printf("name=%s\n",(*s)[*n]->name);
  }
  err=0;
 
 rewind(f);
 int gr; char name[256]; float rat;
 for(*n=0;fgets(str,sizeof(str),f)!=NULL;(*n)++)
  {
   if(i==1)
   {
    (*arr)[*n]=Create();
     for(si=str;sscanf(si,"%d %s %f",&gr,name,&rat)==1;si+=l)
     {InsertAfter((*arr)[*n],name,gr,rat);
      GoToNext((*arr)[*n]);
     }
    GoToBeg((*arr)[*n]);
   } 
  }
   if(i==0)
    {
     *arr=(List **)calloc(sizeof(int *),*n);
    }
 
 }}}
 lc:
 fclose(f);
 lm:
 return err;
}
