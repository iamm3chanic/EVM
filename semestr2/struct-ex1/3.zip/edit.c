#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "fun.h"

void edit(SStudent **s, SStudent ***great, List ***arr, int n, int *g)
{
 int i,j,m,flag=0;
 //char u[256]="----------------------";
 //dif=n/10;
 m=n;
 
 for(i=0;i<(n);i++)
  {
   for(size_t j=0;j<strlen(s[i]->name);j++)
   {
   if ((s[i]->name[j] >= 'A' && s[i]->name[j] <='Z') ||
       (s[i]->name[j] >= 'a' && s[i]->name[j] <= 'z'))
       {flag=1;}
   }
   {if(flag) {m--;} /*printf("%d\n\n",m);*/ flag=0;} 
  }
 
 //if(m)
 flag=0;
 *great=(SStudent**)malloc((m)*sizeof(**great));
 for(j=0;j<(m);j++) (*great)[j]=(SStudent*)malloc(sizeof(***great));
 //printf("dif=%d\n",dif);
 //printf("n=%d\n",n);
 //printf("m=%d\n",m);
  for(int k=0,i=0; (i<n); i++)
   {
   
   for(size_t j=0;j<strlen(s[i]->name);j++)
   {
   if ((s[i]->name[j] >= 'A' && s[i]->name[j] <='Z') ||
       (s[i]->name[j] >= 'a' && s[i]->name[j] <= 'z'))
       {flag=1;}
   }
   {
   if(!flag)
    {
     *(*great)[k]=*(s)[i]; 
     memcpy((*great)[k],(s)[i],sizeof(*(s)[i]));
     //printf("ss=%s\n",(s)[i]->name);
     //printf("gr=%s\n",(*great)[k]->name);
     k++; 
    } 
     flag=0;
   } 
  }
  
  *g=m;
  //strcpy(((*great)[dif])->name, u);
  //strcpy(((*great)[m-dif-1])->name, u);
  //(*great)[dif]->group=0;
  //(*great)[dif]->rating=0.0;
  //(*great)[m-dif-1]->group=0;
  //(*great)[m-dif-1]->rating=0.0;
  /*for(i=dif+1; i<(m-dif-1); i++)
  {*(*great)[i]=*(s)[i-1];}
  for(i=m-dif; i<m; i++)
  *(*great)[i]=*(s)[i-2];*/
}
