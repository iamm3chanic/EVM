#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "fun.h"
#include "str.h"

void output2(SStudent **s, int n)
{
  printf("%d %s %f\n", (s[0])->group, (s[0])->name, (s[0])->rating);
  for(int i=1;i<n;i++)
  {
   if((s[i])->group > (s[i-1])->group) {printf("-------------------------\n");}
   printf("%d %s %f\n", (s[i])->group, (s[i])->name, (s[i])->rating);
  }
}
