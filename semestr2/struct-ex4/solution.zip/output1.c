#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "fun.h"
#include "str.h"

int output1(const char *fn, List *s, int n)
{
 FILE *ff;
 int err=0;
 GoToBeg(s);
  SStudent tmp=*(s->first);
 
 ff=fopen(fn,"w");
 if(ff==NULL) {err=-1;goto lc;}//not found
 else
  {
   for(int i=0;i<n && !GoToNext(s);i++)
  {
   if((s)->curr->group > tmp.group) {fprintf(ff,"-------------------------\n");}
   fprintf(ff,"%d %s %f\n", (s)->curr->group, (s)->curr->name, (s)->curr->rating);   
   tmp = *(s->curr);
  }
  
  err=0;
  fclose(ff);
 }
 lc:
 return err;
}
