#ifndef __FUN_H__
#define __FUN_H__
#include "str.h"
int input1(const char *fn, List **arr, int *n);
int output1(const char *fn, List *l, int n);
void output2(List *s, int n);
void sort(List **s, int n);
void edit(List **arr, int n, int *g);
List *Create(void);
void Destruct(List *a);
int GoToNext(List *a);
void GoToBeg(List *a);
void InsertAfter(List *m, char* name, int group, float rating);
int IsEmpty(List *a);
int Func(const char *SoutputFile, List **arr, int *m);
#endif
