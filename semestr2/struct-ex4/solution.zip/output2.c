#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "fun.h"
#include "str.h"

void output2(List *s, int n)
{
  GoToBeg(s);
  SStudent tmp=*(s->first);
  for(int i=0;i<n && !GoToNext(s);i++)
  {
   if((s)->curr->group > tmp.group) {printf("-------------------------\n");}
   printf("%d %s %f\n", (s)->curr->group, (s)->curr->name, (s)->curr->rating);   
   tmp = *(s->curr);
  }
}
