#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <errno.h>
#include "fun.h"
#include "str.h"


static void
decomment_file (FILE *fp, FILE *res)
{
 
  int ch, next, is_inside_comment, is_inside_quote;\
  
 res=fopen("no-comment.txt","w");
 if(res==NULL) {printf("can't create file\n");goto lc;}//not found
 else
  {
    
  is_inside_comment = 0;
  is_inside_quote = 0;
  while ((ch = fgetc (fp)) != EOF)
    {
      if (is_inside_quote)
        {
          if (1)
           { putchar (ch); fprintf(res,"%c",ch);}
 
          if (ch == '\"')
            is_inside_quote = 0;
        }
      else if (is_inside_comment)
        {
          if (ch == '*')
            {
              next = fgetc (fp);
              if (next == '/')
                is_inside_comment = 0;
            }
        }
      else
        {
          if (ch == '\"')
            is_inside_quote = 1;
          else if (ch == '/')
            {
              next = fgetc (fp);
              if (next == '*')
                {
                  is_inside_comment = 1;
                  continue;
                }
 
              putchar (ch);
              fprintf(res,"%c",ch);
              ch = next;
            }
 
          putchar (ch);
          fprintf(res,"%c",ch);
        }
    }
   
   
   
  fclose(res);
 }
 lc:
 return ;
  
}



int input1(const char *fn, List **arr, int *n)
{
 FILE *f,*res1,*res2;
 int i,err,r;
 float sh;
 char str[512],u[512],t; //, *si,l;
 f=fopen(fn,"r");
 if(f==NULL){err=-1;goto lm;}//not found
 else{
 if(fgets(str,512,f)==NULL) {err=-2; goto lc;}//empty file
 else{
 if(sscanf(str,"%c",&t)!=1) {err=-3; goto lc;}//empty file2
 
 else
 {
 
 rewind(f);
 int gr,l1,l2; char name[256], *ss; float rat;
 printf("\nDELETE COMMENTS:\n\n");
 decomment_file(f,res1);
   
   
 res2=fopen("no-comment.txt","r");
 if(res2==NULL){err=-1;goto lm;}//not found
 else{
 if(fgets(str,512,res2)==NULL) {err=-2; goto lc;}//empty file
 else{
 if(sscanf(str,"%c",&t)!=1) {err=-3; goto lc;}//empty file2


 for(*n=0;fgets(str,512,res2)!=NULL&&sscanf(str,"%d %s %f",&r,u,&sh)==3;(*n)++)
  {}
  if(*n)
   *arr=(List *)malloc(sizeof(int *)*(*n));
  //for(i=0;i<(*n);i++) 
  { (*arr)=Create();}
  //(*s)[i]=(SStudent*)malloc(sizeof(***s));
  rewind(f);
  for(*n=0,i=0;fgets(str,512,res2)!=NULL&&sscanf(str,"%d%n",&gr,&l1)==1;(*n)++, i++)
  {
  if((ss=strchr(str,'\n'))!=NULL) *ss='\0';
  ss=str+l1;
  if(sscanf(ss," %g%n",&rat,&l2)==1){}  
  
  while(isspace(*ss))ss++; 
  ss+=l2;
  while(isspace(*ss))ss++; 
  strcpy((name),ss);
  
  /*if(!sscanf(str,"%d", &y) && sscanf(str,"%s", t))
  {strcat(name,t);}*/
  if(*(name)=='\0') return -4;
  //printf("name=%s\n",name);
  InsertAfter((*arr),name,gr,rat); GoToNext((*arr));
  }
 err=0;
 
 }
 fclose(res2);
 }}}}
 lc:
 fclose(f); 
 lm:
 return err;

}
