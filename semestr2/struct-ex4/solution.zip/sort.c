#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "fun.h"

void sort(List **l, int n)
{
 SStudent *s;
 s=(SStudent*)malloc((n)*sizeof(*s));
 GoToBeg(*l);
 for(int j=0;j<(n) && !GoToNext((*l));j++) {s[j]=*(*l)->curr; }
 s[0]=*(*l)->first;
 s[n-1]=*(*l)->last;
 
 
 Destruct(*l);
 (*l)=Create();
 int i,j;
 SStudent t;
 for(i=0; i<n-1; i++) 
  {for(j=0; j<n-1; j++)
  if ((((s)[j]).group) > (((s)[j+1]).group))
  {
   (t)=(s)[j];
   (s)[j]=(s)[j+1];
   (s)[j+1]=(t);
  }
  }
  
  for(int i=0;i<n; i++)
  {
  InsertAfter((*l),s[i].name,s[i].group,s[i].rating); 
  GoToNext((*l));
  }
  
  
  /*
  ///////////////OK/////////////
  GoToBeg(*l);
  for(int i=0;i<n && !GoToNext(*l);i++)
  {
   printf("%d %s %f\n", (*l)->curr->group, (*l)->curr->name, (*l)->curr->rating);
   printf("%d %s %f\n", (s[i]).group, (s[i]).name, (s[i]).rating);
  }
  */
  free(s);
}
