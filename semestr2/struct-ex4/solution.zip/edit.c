#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "fun.h"

void edit(List **l, int n, int *g)
{
 int m,flag=0; //i,j,
 SStudent *s, *s1; 
 s=(SStudent*)malloc((n)*sizeof(*s));
 GoToBeg(*l);
 for(int j=0;j<(n) && !GoToNext((*l));j++) {s[j]=*(*l)->curr; }
 s[0]=*(*l)->first;
 s[n-1]=*(*l)->last;
 
 Destruct(*l);
 (*l)=Create();
 
 m=n;
 
 for(int i=0;i<(n);i++)
  {
   if ((s[i].group >= 1000) ||
       (s[i].group <= 99))
       {flag=1;}
   
   {if(flag) {m--;} /*printf("%d\n\n",m);*/ flag=0;} 
  }
 
 //if(m)
 flag=0;
 
 s1=(SStudent*)malloc((n)*sizeof(*s1));

  for(int k=0,i=0; (i<n); i++)
   {
   
   if ((s[i].group >= 1000) ||
       (s[i].group <= 99))
       {flag=1;}
   
   {
   if(!flag)
    {
     s1[k]=s[i];
     k++; 
    } 
     flag=0;
   } 
  }
  
  *g=m;
  
  
  for(int i=0;i<*g;i++)
 {
  InsertAfter((*l),(s1)[i].name,(s1)[i].group,(s1)[i].rating);
  GoToNext((*l));
 }
 
  free(s); free(s1);
}
