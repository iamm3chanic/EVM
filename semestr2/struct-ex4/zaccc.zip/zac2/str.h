#pragma once
typedef
struct SStudent_
{
 char name[256];
 float rating;
}SStudent;