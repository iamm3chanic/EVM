#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <ctype.h>
#include <string.h>
#include "fun.h"
#include "str.h"

int main(void)
{
 int errin=0,errout1=0,errout=0,n,m,i=0;
 SStudent *s, *neww, *tmp;
 errin=input1("data.dat", &s,&n);
 printf("checked errin=%d\n",errin);
 if(errin==-1)printf("infile not found\n");
 if(errin==-2)printf("empty infile\n");
 else if(errin==0)
 {
  //printf("check\n");
  errout=output1("datashort.res", s,n);
  printf("checked errout=%d\n",errout);
  if (errout==-1)
   {printf("outfile not found\n"); for(i=0;i<n;i++) free (&s[i]); free(s);}
  else
   {
  // printf("check\n");
    sort(s,n,&tmp);
//    printf("check\n");
//    output2(tmp,n);
    edit(tmp,&neww,n,&m);
//    printf("check\n");
    printf("-----------------------------\n");
    output1("datashort.res", neww,m);
    output2(neww,m);
//    for(i=0;i<n;i++) {free (&s[i]);free (&tmp[i]);}
//    for(i=0;i<m;i++) {free (&neww[i]);}
    /*free(s);*/ //free(neww); free(tmp);
    printf("-----------------------------\nwork finished with exit code 0\n");
   }
 }
return errin+errout;
}
