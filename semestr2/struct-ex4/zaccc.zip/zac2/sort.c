#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "fun.h"

void sort(SStudent *s, int n, SStudent **tmp)
{
 int i,j;
 SStudent t; //SStudent** tmp;
 *tmp=(SStudent*)malloc((n)*sizeof(*tmp)); //собсно, создаю и копирую
  for(j=0; j<n; j++)
  {
  //printf("name=%s\n", ((&s[j])->name));
  (tmp)[j]=(SStudent*)malloc(sizeof(**tmp));
  memcpy((tmp)[j],(&s[j]),sizeof(*s));
 // printf("name=%s\n", &(((tmp)[j])->name));
  }
 
 for(i=0; i<n-1; i++) 
  for(j=0; j<n-1; j++)
  if ((((tmp)[j])->rating) > (((tmp)[j+1])->rating))
  {
   memcpy(&t,(tmp)[j],sizeof(**tmp));
   memcpy((tmp)[j],(tmp)[j+1],sizeof(**tmp));
   memcpy((tmp)[j+1],(&t),sizeof(**tmp));
  //printf("sorting...\n");
  }
}