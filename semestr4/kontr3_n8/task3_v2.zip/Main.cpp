/*
 * Main.cpp
 * WARNING: WHILE COMPILATION WITH VALGRIND IT MAY TAKE over 36 sec ON 138604 VECTORS OF DATA.
 * processor intel core i5, OS Linux Fedora 32
 */

#include <iostream>
#include "CVektor.h"

using namespace std;


int main()
{
  try {
   cout << "test1. Input + parallel\n";
vector<CFabricVektor*> fabric;
vector<CVektor*> v;
   //HERE WERE LEAKAGE
   fabric.push_back(new CFabricVektor0);
   fabric.push_back(new CFabricVektor1);
   
   CVektor::Input("input.txt", v, fabric);
   CVektor::ParallelTest(v);
   cout<<"global Number = "<<v.size()<<endl;
   for(size_t i=0;(i<v.size());++i)  
   {
   // v[i]->output("input.txt");
    //v[i]->ShowVektor();
   }
    for(size_t i=0;(i<v.size());i++)  {delete v[i];}
    for(size_t i=0;(i<fabric.size());i++)  {delete fabric[i];}
   //delete &fabric;
  // delete[] glob_v;
  } catch(...) {cout << "error\n" <<endl;} 
  
  try {
   cout << "test2. Move assignment\n";
   CVektor0 v1(1),v2(2),v3(3);
   CVektor1 u1(1),u2(2),u3(3);
   v1.setPos(0,39); v2.setPos(0,43); v2.setPos(1,56); v3.setPos(0,1); v3.setPos(1,2); v3.setPos(2,3);
   u1.setPos(0,39); u2.setPos(0,43); u2.setPos(1,56); u3.setPos(0,1); u3.setPos(1,2); u3.setPos(2,3);
   cout<<"CVektor0. default.\nv1="<<v1<<"v2="<<v2<<"v3="<<v3;
   cout<<"MOVING v2 to v1...\n";
   v1=std::move(v2);
   cout<<"v1="<<v1<<"v2="<<v2;
   cout<<"MOVING v3 to v2...\n";
   v2=std::move(v3);
   cout<<"v2="<<v2<<"v3="<<v3;
   
   cout<<"\nCVektor1. user-defined.\nu1="<<u1<<"u2="<<u2<<"u3="<<u3;
   cout<<"MOVING u2 to u1...\n";
   u1=std::move(u2);
   cout<<"u1="<<u1<<"u2="<<u2;
   cout<<"MOVING u3 to u2...\n";
   v2=std::move(v3);
   cout<<"u2="<<u2<<"u3="<<u3;
   
  } catch(...) {cout << "error\n" <<endl;} 
  
 
        return 0;
}
